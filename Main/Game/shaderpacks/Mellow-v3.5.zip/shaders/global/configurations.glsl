// DONTOPTIMIZE-START

// It's actually sometimes faster to have this clear
const bool colortex0Clear = true;

const bool colortex1Clear = false;
const bool colortex2Clear = false;
const bool colortex3Clear = false;
const bool gaux1Clear = false;
const bool gaux2Clear = false;
const bool colortex8Clear = false;
const bool colortex9Clear = false;
const bool shadowcolor0Clear = false;

const vec4 colortex0ClearColor = vec4(0,0,0,0);
const vec4 colortex1ClearColor = vec4(0,0,0,1);

const float shadowDistanceRenderMul = 1.0;
const bool shadowHardwareFiltering = true;

/*
const int colortex0Format = R11F_G11F_B10F;
const int colortex1Format = R11F_G11F_B10F;
const int colortex2Format = RGBA8;
const int colortex8Format = R11F_G11F_B10F;
const int colortex9Format = R11F_G11F_B10F;
const int shadowcolor0Format = R3_G3_B2;
const int gaux1Format = R11F_G11F_B10F;
const int gaux2Format = RG16; 
*/

#if SUN_PATH_ROTATION == -40
    const float sunPathRotation = -40;
#elif SUN_PATH_ROTATION == -35
    const float sunPathRotation = -35;
#elif SUN_PATH_ROTATION == -30
    const float sunPathRotation = -30;
#elif SUN_PATH_ROTATION == -25
    const float sunPathRotation = -25;
#elif SUN_PATH_ROTATION == -20
    const float sunPathRotation = -20;
#elif SUN_PATH_ROTATION == -15
    const float sunPathRotation = -15;
#elif SUN_PATH_ROTATION == 0
    const float sunPathRotation = 0;
#elif SUN_PATH_ROTATION == 15
    const float sunPathRotation = 15;
#elif SUN_PATH_ROTATION == 20
    const float sunPathRotation = 20;
#elif SUN_PATH_ROTATION == 25
    const float sunPathRotation = 25;
#elif SUN_PATH_ROTATION == 30
    const float sunPathRotation = 30;
#elif SUN_PATH_ROTATION == 35
    const float sunPathRotation = 35;
#elif SUN_PATH_ROTATION == 40
    const float sunPathRotation = 40;
#else
    const float sunPathRotation = SUN_PATH_ROTATION; // Doesn't work with optifine
#endif

#if SHADOW_MAP_RESOLUTION == 512
    const int shadowMapResolution = 512;
#elif SHADOW_MAP_RESOLUTION == 1024
    const int shadowMapResolution = 1024;
#elif SHADOW_MAP_RESOLUTION == 2048
    const int shadowMapResolution = 2048;
#elif SHADOW_MAP_RESOLUTION == 4096
    const int shadowMapResolution = 4096;
#elif SHADOW_MAP_RESOLUTION == 8192
    const int shadowMapResolution = 8192;
#else
    const int shadowMapResolution = SHADOW_MAP_RESOLUTION;
#endif

// DONTOPTIMIZE-END